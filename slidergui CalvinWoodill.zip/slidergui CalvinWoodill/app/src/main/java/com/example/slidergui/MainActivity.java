package com.example.slidergui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button2;
    TextView label;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBar = (SeekBar)findViewById(R.id.seekBar);
        button2 = findViewById(R.id.button2);
        label = findViewById(R.id.label);
        button2.setOnClickListener(new View.OnClickListener() {
            public boolean buttonpushed = false;
            public void onClick(View v) {
                if  (!buttonpushed) {
                    label.setTextColor(getResources().getColor(R.color.purple_200));
                    buttonpushed = true;
                }
                else
                {
                    label.setTextColor(getResources().getColor(R.color.teal_200));
                    buttonpushed = false;
                }


            }
        });
seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        //set alpha and 0 to 1
        label.setAlpha((float)progress/255);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
});
    }
}