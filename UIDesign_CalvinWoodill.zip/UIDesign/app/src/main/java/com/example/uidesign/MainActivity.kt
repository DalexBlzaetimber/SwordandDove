package com.example.uidesign

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}

/*
the three buttons at the bottom would change between activities.
the radio button would turn on radio mode allowing access to AM/FM radio using search bar to tune it and an auto search function
the clock will lead to alarm setup. The + would allow adding new media and the pla button would play the selected media mode.
the radio and cd mode will be unable to be selected at the same time. Red x button on the alarm and add music file would delete selected media.

 */