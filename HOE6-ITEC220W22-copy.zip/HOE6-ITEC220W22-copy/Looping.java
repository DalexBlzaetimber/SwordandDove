import java.util.Scanner;
/**
 * Write a description of class Looping here.
 *
 * @author Calvin Woodill
 * @version (a version number or a date)
 */
public class Looping 
{
 public static Scanner sc; 
 public static void main(String[] args) 
 {
        int i = 1, num, sum = 0;
    final int LIMIT = 1000;
    sc = new Scanner(System.in);    
    System.out.println("put in a number");
    num = sc.nextInt(); 
     while (i < num){ 
        if(num%i == 0){
        sum = sum +i;
        }
        i++;
    }
    if(sum > LIMIT) {
           System.out.println("OVER LIMIT DUMMY"+ num);
    }
    else
    if(sum == num) {
        System.out.println("%d is a Perfect Number..."+ num);
    }
    else {
        System.out.println("%d is a not Perfect Number..LOSER."+ num);
    }
}
}
