package com.example.teachertheater;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

/* setup is simple select the share chip to share a choosen computer then use
can see each computer based on the selected node. It displas on the webview or over the
 network. Able to share between each joined device with a scroll view to see other
 instances in the list. The control mode would let selected computers be under the
 control of the theater controller until toggled off either by the switch or the chip**/