import './style.css';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import * as dat from 'lil-gui';
import { TorusGeometry } from 'three';

// Control Panel - Debug
const gui = new dat.GUI();

// Canvas
const canvas = document.querySelector('canvas.webgl');

// Scene
const scene = new THREE.Scene();

/** Lights */
// Ambient light
const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
gui.add(ambientLight, 'intensity').min(0).max(1).step(0.001);
scene.add(ambientLight);

// Directional light
const directionalLight = new THREE.DirectionalLight(0xffffff, 0.3);
directionalLight.position.set(2, 2, -1);
scene.add(directionalLight);

directionalLight.castShadow = true;

directionalLight.shadow.mapSize.width = 1024;
directionalLight.shadow.mapSize.height = 1024;

directionalLight.shadow.camera.near = 1;
directionalLight.shadow.camera.far = 6;

const directionalLightCameraHelper = new THREE.CameraHelper(
	directionalLight.shadow.camera
);
directionalLightCameraHelper.visible = true;
scene.add(directionalLightCameraHelper);

directionalLight.shadow.camera.top = 2;
directionalLight.shadow.camera.right = 2;
directionalLight.shadow.camera.bottom = -2;
directionalLight.shadow.camera.left = -2;

directionalLight.shadow.radius = 10;

gui.add(directionalLight, 'intensity').min(0).max(1).step(0.001);
gui.add(directionalLight.position, 'x').min(-5).max(5).step(0.001);
gui.add(directionalLight.position, 'y').min(-5).max(5).step(0.001);
gui.add(directionalLight.position, 'z').min(-5).max(5).step(0.001);

// Spot light
const spotLight = new THREE.SpotLight(0xffffff, 0.3, 10, Math.PI * 0.3);
spotLight.position.set(0, 2, 2);
scene.add(spotLight);
scene.add(spotLight.target);
spotLight.castShadow = true;

const spotLightCameraHelper = new THREE.CameraHelper(spotLight.shadow.camera);
spotLightCameraHelper.visible = true;
scene.add(spotLightCameraHelper);

spotLight.shadow.mapSize.width = 1024;
spotLight.shadow.mapSize.height = 1024;

spotLight.shadow.camera.near = 1;
spotLight.shadow.camera.far = 6;

spotLight.shadow.camera.fov = 30;

//const spotLightCameraHelper = new THREE.CameraHelper(spotLight.shadow.camera);
//spotLightCameraHelper.visible = false;
//scene.add(spotLightCameraHelper);

// Point light
const pointLight = new THREE.PointLight(0xffffff, 0.3);
pointLight.position.set(-1, 1, 0);
scene.add(pointLight);
pointLight.castShadow = true;

const pointLightCameraHelper = new THREE.CameraHelper(pointLight.shadow.camera);
pointLightCameraHelper.visible = true;
scene.add(pointLightCameraHelper);

pointLight.shadow.mapSize.width = 1024;
pointLight.shadow.mapSize.height = 1024;

pointLight.shadow.camera.near = 0.1;
pointLight.shadow.camera.far = 5;

//Sizes - resize/fullscreen
const sizes = {
	width: window.innerWidth,
	height: window.innerHeight,
};

window.addEventListener('resize', () => {
	// Update sizes
	sizes.width = window.innerWidth;
	sizes.height = window.innerHeight;

	// Update camera
	camera.aspect = sizes.width / sizes.height;
	camera.updateProjectionMatrix();

	// Update renderer
	renderer.setSize(sizes.width, sizes.height);
	renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
});

//Object - Mesh (Geometry & Material)////////////////////////////////////////////

const material = new THREE.MeshStandardMaterial();
material.roughness = 0.7;
gui.add(material, 'metalness').min(0).max(1).step(0.001);
gui.add(material, 'roughness').min(0).max(1).step(0.001);

// Objects
const truck = new THREE.Group();
const wheels = new THREE.Group();
const cube = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.25, 1), material);
cube.castShadow = true;

const cube2 = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 1), material);
cube2.castShadow = true;
cube2.position.x = 0.5;
cube2.position.y = 0.2;
const wheel = new THREE.Mesh(new THREE.TorusGeometry( 10, 3, 16, 100 ), material);
wheel.scale.x = 0.025;
wheel.scale.y = 0.026;
wheel.scale.z = 0.05;
wheel.position.x = 0.5;
wheel.position.z = 0.5;
wheel.position.y = -0.25
wheel.castShadow = true;
const wheel2 = new THREE.Mesh(new THREE.TorusGeometry( 10, 3, 16, 100 ), material);
wheel2.scale.x = 0.025;
wheel2.scale.y = 0.026;
wheel2.scale.z = 0.05;
wheel2.position.x = 0.5;
wheel2.position.z = -0.5;
wheel2.position.y = -0.25
wheel2.castShadow = true;
const wheel3 = new THREE.Mesh(new THREE.TorusGeometry( 10, 3, 16, 100 ), material);
wheel3.scale.x = 0.025;
wheel3.scale.y = 0.026;
wheel3.scale.z = 0.05;
wheel3.position.x = -0.5;
wheel3.position.z = -0.5;
wheel3.position.y = -0.25
wheel3.castShadow = true;
const wheel4 = new THREE.Mesh(new THREE.TorusGeometry( 10, 3, 16, 100 ), material);
wheel4.scale.x = 0.025;
wheel4.scale.y = 0.026;
wheel4.scale.z = 0.05;
wheel4.position.x = -0.5;
wheel4.position.z = 0.5;
wheel4.position.y = -0.25
wheel4.castShadow = true;

const plane = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), material);
plane.rotation.x = -Math.PI * 0.5;
plane.position.y = -0.5;
plane.receiveShadow = true;
wheels.add(wheel, wheel2, wheel3, wheel4);
truck.add(cube, cube2, wheel, wheel2, wheel3, wheel4, wheels);
scene.add(plane, truck)

//Camera
const camera = new THREE.PerspectiveCamera(
	75,
	sizes.width / sizes.height,
	0.1,
	100
);
camera.position.set(1, 1, 2);
scene.add(camera);

// Controls
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;

//Renderer
const renderer = new THREE.WebGLRenderer({
	canvas: canvas,
});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

//Animate using THREE.js Clockorbit control
const clock = new THREE.Clock();
const tick = () => {
	const elapsedTime = clock.getElapsedTime();

	// Update object
	// cube.rotation.y = 0.15 * elapsedTime
	// sphere.rotation.x = 0.15 * elapsedTime
	 wheel.rotation.z += 0.5 * elapsedTime
	 wheel2.rotation.z += 0.5 * elapsedTime
	 wheel3.rotation.z += 0.5 * elapsedTime
	 wheel4.rotation.z += 0.5 * elapsedTime
	 const truckAngle = elapsedTime * 0.18;
	 truck.position.x = Math.cos(truckAngle) * (7 + Math.sin(elapsedTime * 0.32));
	

	// Update controls
	controls.update();

	// Render
	renderer.render(scene, camera);

	// Call tick again on the next frame
	window.requestAnimationFrame(tick);
};
tick();
