package com.example.myapplication;


import androidx.recyclerview.widget.RecyclerView;

public interface StartDragListener {
    void requestDrag(RecyclerView.ViewHolder viewHolder);

    void requestDrag(RecyclerViewAdapter.MyViewHolder viewHolder);
}