package com.example.smartcookingassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUserInput;
    private ListView listViewRecipeList;
    private TextView textViewRecipeDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextUserInput = findViewById(R.id.editText_user_input);
        listViewRecipeList = findViewById(R.id.listView_recipe_list);
        textViewRecipeDetails = findViewById(R.id.textView_recipe_details);

        // Set OnItemClickListener for recipe list
        listViewRecipeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedRecipe = (String) parent.getItemAtPosition(position);
                // Set recipe details text view
                textViewRecipeDetails.setText(selectedRecipe);
            }
        });

        // Set OnClickListener for start cooking button
        Button buttonStartCooking = findViewById(R.id.button_start_cooking);
        buttonStartCooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start cooking based on selected recipe
                // You could add additional functionality here to guide the user through the recipe execution
            }
        });
    }

    // Method to handle search button click
    public void searchRecipes(View view) {
        // Get user input text
        String userInput = editTextUserInput.getText().toString();

        // Validate user input
        if (userInput.isEmpty()) {
            Toast.makeText(this, "Please enter a recipe", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create search query based on user input
        String searchQuery = userInput + " recipe";

        // Perform recipe search based on search query
        ArrayList<String> recipeList = performRecipeSearch(searchQuery);

        // Display search results in recipe list view
        ArrayAdapter<String> recipeListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, recipeList);
        listViewRecipeList.setAdapter(recipeListAdapter);
    }

    // Method to perform recipe search based on search query
    private ArrayList<String> performRecipeSearch(String searchQuery) {
        // You could add additional functionality here to search a recipe database and return a list of recipes based on the search query
        // For now, just return a dummy list of recipes
        ArrayList<String> recipeList = new ArrayList<>();
        recipeList.add("Spaghetti Bolognese");
        recipeList.add("Chicken Curry");
        recipeList.add("Pizza Margherita");
        return recipeList;
    }
}
