import java.util.Scanner;
/**
 * Allows for student information to be added.
 *
 * @author (Calvin Woodill)
 * @version (4/13/2022)
 */
// set the classd and string setup made it relay on persons for extra informati
public class Student extends Person {
   private String degree;
   private double points;
   public Student() {
   }
   @Override
   // setup the inputs added some humor
   public void setData() {
       super.setData();
       Scanner scan = new Scanner(System.in);
       System.out.print("Enter the student's degree pain in the class: ");
       this.degree = scan.nextLine();
       System.out.print("Enter Student's Points from cheating is: ");
       this.points = scan.nextDouble();
       scan.nextLine();
   }
   @Override
   // added a final output for showing an end statment for display
   public String display() {
       return super.display() + "\n" + " Degree: " + degree + " Points: " + points;
   }
}
