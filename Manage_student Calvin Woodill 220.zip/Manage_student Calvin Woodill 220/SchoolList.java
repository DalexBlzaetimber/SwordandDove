import java.util.Scanner;
/**
 * this will allow the selection of the student folder to add the student information.
 *
 * @author (Calvin Woodill)
 * @version (4/13/2022)
 */
//setting vlass and string information, adapted from old assignmernt
public class SchoolList {
   public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       Person[] persons = new Person[14];
       String choice;
       int i = 0;
       do {
           menu();
           // added information to allow for choice to choose student or quit
           System.out.print("Enter the choice: ");
           // setup choice input
           choice = scan.nextLine();
           switch (choice.toUpperCase().charAt(0)) {
           case 'S':
               persons[i] = new Student();
               i++;
               break;
           case 'Q':
               try {
                   for (Person person : persons) {
                       System.out.println(person.display());
                       System.out.println();
                   }
               } catch (Exception e) {
               }
               break;
           default:
               //output if invalid choice
               System.out.println("Invalid choice!try again dummy how did you even get into this school");
               break;
           }
       } while (choice.toUpperCase().charAt(0) != 'Q');
   }
   public static void menu() {
       System.out.println("S)tudent.\n" + "Q)uit.");
   }
}