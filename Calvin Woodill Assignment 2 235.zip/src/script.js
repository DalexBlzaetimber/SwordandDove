import './style.css'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import gsap from 'gsap'
import * as dat from 'lil-gui';

/**
 * Base
 */
// Canvas
const canvas = document.querySelector('canvas.webgl')

// Scene
const scene = new THREE.Scene()

/**
 * Object
 */
const geometry = new THREE.CapsuleGeometry( 4, 2, 4, 8 );
const material = new THREE.MeshBasicMaterial({color: 0xffff00})
const capsule = new THREE.Mesh(geometry, material)
scene.add(capsule)

/**
 * Sizes
 */
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

/**
 * Camera
 */
// Base camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100)
camera.position.z = 8
scene.add(camera)

// Controls
const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true

/**
 * Renderer
 */
const renderer = new THREE.WebGLRenderer({
    canvas: canvas
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

/**
 * Debug
 */
 const gui = new dat.GUI()
 gui.add(capsule.position, 'y').min(- 3).max(3).step(0.01).name('elevation');
 gui.add(capsule.position, 'x').min(- 3).max(3).step(0.01).name('x axis');
 gui.add(capsule, 'visible');
 const materialParams = { 
    capsuleColor: capsule.material.color.getHex(),
};
 gui.add(material, 'wireframe');
 gui
    .addColor(materialParams,'capsuleColor')
    .onChange((value) => capsule.material.color.set(value));
/**
 * Animate
 */
const clock = new THREE.Clock()

const tick = () =>
{
    const elapsedTime = clock.getElapsedTime()

    // Update controls
    controls.update()

    // Render
    renderer.render(scene, camera)

gsap.to(capsule.position, {rotation: +27, delay: 2, x: +4, y: +3, z: +5,  duration: 5, scale: +3});
gsap.to(capsule.position, {rotation: -27, delay: 5,  x: -4, y: -3, z: -5, duration: 5, scale: -3 });
gsap.to(capsule.position, {rotation: +27, delay: 11, x: +4, y: +3, z: +5,  duration: 5, scale: +3});
gsap.to(capsule.position, {rotation: -27, delay: 20,  x: -4, y: -3, z: -5, duration: 5, scale: -3 });
gsap.to(capsule.position, {rotation: 27, delay: 30,  x: 4, y: 3, z: 5, duration: 5, scale: 1 });
capsule.rotation.y += 0.01;

    // Call tick again on the next frame
    window.requestAnimationFrame(tick)
}

tick()
