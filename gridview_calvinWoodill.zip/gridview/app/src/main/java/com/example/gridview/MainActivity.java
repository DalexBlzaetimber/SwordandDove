package com.example.gridview;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gridview.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
 ActivityMainBinding binding;

 @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =  ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String[] animalNames = {"bird","cat","chicken","dog","fish","lion","monkey","rabbit","sheep"};
        int[] animalImages = {R.drawable.bird,R.drawable.cat,R.drawable.chicken,R.drawable.dog,R.drawable.fish,
                R.drawable.lion,R.drawable.monkey,R.drawable.rabbit,R.drawable.sheep};
        GridAdapter gridAdapter = new GridAdapter(MainActivity.this,animalNames,animalImages);
        binding.gridview.setAdapter(gridAdapter);

        binding.gridview.setOnItemClickListener((adapterView, view, i, l) -> Toast.makeText(MainActivity.this,"you clicked this "+ animalNames[i], Toast.LENGTH_SHORT).show());
    }
}