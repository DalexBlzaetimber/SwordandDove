"use strict";
/*
   New Perspectives on HTML5 and CSS3, 7th Edition
   Tutorial 9
   Tutorial Case

   Countdown Clock
   Author: Calvin Woodill
   Date:   2021-11-18

*/

/* Execute the function to run popup display */
window.alert("welcome to Sword and dove please Check me out on facebook and on youtube");